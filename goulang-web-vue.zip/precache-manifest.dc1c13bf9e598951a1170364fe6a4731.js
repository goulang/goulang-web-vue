self.__precacheManifest = [
  {
    "revision": "422283f3e925ad36258e",
    "url": "/css/reset.aa8d5578.css"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "422283f3e925ad36258e",
    "url": "/js/reset.ce7aa41a.js"
  },
  {
    "revision": "bef42ec042a61a76e0ad",
    "url": "/css/books.678acf3e.css"
  },
  {
    "revision": "12afd51750481d3cf0f9",
    "url": "/css/chunk-vendors.e51f3d13.css"
  },
  {
    "revision": "12afd51750481d3cf0f9",
    "url": "/js/chunk-vendors.f34c105f.js"
  },
  {
    "revision": "25a1f8e29c93d8e53782",
    "url": "/css/details.678acf3e.css"
  },
  {
    "revision": "25a1f8e29c93d8e53782",
    "url": "/js/details.66d3f6aa.js"
  },
  {
    "revision": "a2f22bc46dafb2ac44f1",
    "url": "/css/editor.61dbc4ae.css"
  },
  {
    "revision": "a2f22bc46dafb2ac44f1",
    "url": "/js/editor.d4d57ed7.js"
  },
  {
    "revision": "81f92f9f59ad48ef600e",
    "url": "/css/forgetpwd.50ecaadd.css"
  },
  {
    "revision": "81f92f9f59ad48ef600e",
    "url": "/js/forgetpwd.ca783440.js"
  },
  {
    "revision": "89a75fe0195080bfb4c7",
    "url": "/css/glweekly.95c6e473.css"
  },
  {
    "revision": "89a75fe0195080bfb4c7",
    "url": "/js/glweekly.3dd779ee.js"
  },
  {
    "revision": "ede7e63893eb161e8102",
    "url": "/css/home.b0d28af9.css"
  },
  {
    "revision": "ede7e63893eb161e8102",
    "url": "/js/home.717c660b.js"
  },
  {
    "revision": "04e0c00f1868d0215e57",
    "url": "/css/inform.3e1fddb2.css"
  },
  {
    "revision": "04e0c00f1868d0215e57",
    "url": "/js/inform.91b51063.js"
  },
  {
    "revision": "9f9317606d7c78ad13af",
    "url": "/css/issue.bd79e2ae.css"
  },
  {
    "revision": "9f9317606d7c78ad13af",
    "url": "/js/issue.0d980b62.js"
  },
  {
    "revision": "ae0a6f8f3117ac52bc28",
    "url": "/css/recruit.d50d6ec1.css"
  },
  {
    "revision": "ae0a6f8f3117ac52bc28",
    "url": "/js/recruit.03caab0f.js"
  },
  {
    "revision": "2c95fc18db127627eb89",
    "url": "/js/app.6f6f082b.js"
  },
  {
    "revision": "bef42ec042a61a76e0ad",
    "url": "/js/books.005b03fa.js"
  },
  {
    "revision": "483402cedee54477ec97",
    "url": "/css/setting.0e4a12b7.css"
  },
  {
    "revision": "483402cedee54477ec97",
    "url": "/js/setting.a6613dd4.js"
  },
  {
    "revision": "cbe96516c46ecfeb7ef3",
    "url": "/css/spitslot.85f566e0.css"
  },
  {
    "revision": "cbe96516c46ecfeb7ef3",
    "url": "/js/spitslot.11aecacf.js"
  },
  {
    "revision": "6e326de6172f44e273a4",
    "url": "/css/user.eb29b2dc.css"
  },
  {
    "revision": "6e326de6172f44e273a4",
    "url": "/js/user.f373015f.js"
  },
  {
    "revision": "949c47e933a8f2fca6c5b009a2f6a994",
    "url": "/fonts/iconfont.949c47e9.ttf"
  },
  {
    "revision": "d9329a6ec44d8b9f9385e15e36dc1b42",
    "url": "/fonts/iconfont.d9329a6e.eot"
  },
  {
    "revision": "277ea97eaafaed8bf4f3ac473429c363",
    "url": "/img/iconfont.277ea97e.svg"
  },
  {
    "revision": "a2c4a261a239aa84463dc70e4bac9b9a",
    "url": "/img/ionicons.a2c4a261.svg"
  },
  {
    "revision": "d535a25a79fb1365ae814b61e88fae71",
    "url": "/fonts/ionicons.d535a25a.ttf"
  },
  {
    "revision": "99ac3308dd8ee14f749f51538d0d5b9e",
    "url": "/fonts/ionicons.99ac3308.woff"
  },
  {
    "revision": "f9d2500784e27ab51ee70888cb09e283",
    "url": "/img/avatar.f9d25007.png"
  },
  {
    "revision": "054feeba097b63577c146feb141e60f6",
    "url": "/img/login.054feeba.png"
  },
  {
    "revision": "845251f41501c7d18b052ec31eca4e55",
    "url": "/img/gd.845251f4.png"
  },
  {
    "revision": "b717a54430a4afe85adbfa929f7c53a0",
    "url": "/img/hqy.b717a544.png"
  },
  {
    "revision": "5883c3262e2c66a5d04bf2d1aaf0da89",
    "url": "/img/861.5883c326.png"
  },
  {
    "revision": "0bc7b57f679fa2837a7e0d141bad3c34",
    "url": "/img/go.0bc7b57f.png"
  },
  {
    "revision": "9b128252a83669f94ac95adb19b833ab",
    "url": "/img/logo.9b128252.jpg"
  },
  {
    "revision": "aa2dbca26fcc612a0b317384e8542248",
    "url": "/index.html"
  },
  {
    "revision": "2c95fc18db127627eb89",
    "url": "/css/app.d856641d.css"
  }
];